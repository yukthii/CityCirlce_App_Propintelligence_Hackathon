import { useState } from 'react';
import { Building2, ChevronDown } from 'lucide-react';
import { cities } from './mockData';

interface HomeScreenProps {
  onCitySelect: (city: string) => void;
}

export function HomeScreen({ onCitySelect }: HomeScreenProps) {
  const [selectedCity, setSelectedCity] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const handleEnter = () => {
    if (selectedCity) {
      onCitySelect(selectedCity);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Logo and Title */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-500 to-green-500 rounded-3xl mb-6 shadow-lg">
            <Building2 className="w-10 h-10 text-white" />
          </div>
          <h1 className="mb-3 text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-green-600">
            CityCircle
          </h1>
          <p className="text-gray-600">
            AI-driven People-First Smart City
          </p>
        </div>

        {/* Selection Card */}
        <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12">
          <div className="space-y-6">
            <div>
              <label className="block mb-3 text-gray-700">
                Select Your City
              </label>
              <div className="relative">
                <button
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  className="w-full px-4 py-4 bg-gray-50 border-2 border-gray-200 rounded-2xl text-left flex items-center justify-between hover:border-blue-300 transition-colors"
                >
                  <span className={selectedCity ? 'text-gray-900' : 'text-gray-400'}>
                    {selectedCity || 'Choose a city...'}
                  </span>
                  <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
                
                {isDropdownOpen && (
                  <div className="absolute z-10 w-full mt-2 bg-white border-2 border-gray-200 rounded-2xl shadow-lg max-h-64 overflow-auto">
                    {cities.map((city) => (
                      <button
                        key={city}
                        onClick={() => {
                          setSelectedCity(city);
                          setIsDropdownOpen(false);
                        }}
                        className="w-full px-4 py-3 text-left hover:bg-blue-50 transition-colors first:rounded-t-2xl last:rounded-b-2xl"
                      >
                        {city}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <button
              onClick={handleEnter}
              disabled={!selectedCity}
              className={`w-full py-4 rounded-2xl transition-all ${
                selectedCity
                  ? 'bg-gradient-to-r from-blue-500 to-green-500 text-white hover:shadow-lg hover:scale-[1.02]'
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              }`}
            >
              Enter City Dashboard
            </button>
          </div>
        </div>

        {/* Info Cards */}
        <div className="grid md:grid-cols-2 gap-4 mt-8">
          <div className="bg-white/60 backdrop-blur rounded-2xl p-6 border border-white/50">
            <div className="text-2xl mb-2">🧑‍🤝‍🧑</div>
            <p className="text-gray-700">
              Analyze citizen lifestyle data
            </p>
          </div>
          <div className="bg-white/60 backdrop-blur rounded-2xl p-6 border border-white/50">
            <div className="text-2xl mb-2">🚦</div>
            <p className="text-gray-700">
              Detect road accidents via AI
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
