import { Building2, Sparkles } from 'lucide-react';

interface WelcomeScreenProps {
  onGetStarted: () => void;
}

export function WelcomeScreen({ onGetStarted }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-md text-center">
        {/* Logo */}
        <div className="mb-8 flex justify-center">
          <div className="relative">
            <div className="w-24 h-24 bg-gradient-to-br from-blue-400 to-green-400 rounded-[2rem] flex items-center justify-center shadow-lg">
              <Building2 className="w-12 h-12 text-white" />
            </div>
            <div className="absolute -top-1 -right-1 w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center shadow-md">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
          </div>
        </div>

        {/* App Name */}
        <h1 className="mb-3 text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-green-600">
          CityCircle
        </h1>

        {/* Tagline */}
        <p className="text-gray-600 mb-12 text-lg px-4">
          AI-Powered Smart City Insights for India
        </p>

        {/* Features */}
        <div className="space-y-3 mb-12">
          <div className="bg-white/80 backdrop-blur rounded-2xl p-4 shadow-sm border border-white/50">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                <span className="text-2xl">🧑‍🤝‍🧑</span>
              </div>
              <div className="text-left">
                <p className="text-gray-800">Citizen Risk Analysis</p>
                <p className="text-sm text-gray-500">AI-based lifestyle assessment</p>
              </div>
            </div>
          </div>

          <div className="bg-white/80 backdrop-blur rounded-2xl p-4 shadow-sm border border-white/50">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center flex-shrink-0">
                <span className="text-2xl">🚦</span>
              </div>
              <div className="text-left">
                <p className="text-gray-800">Road Accident Detection</p>
                <p className="text-sm text-gray-500">AI vision for traffic safety</p>
              </div>
            </div>
          </div>
        </div>

        {/* Get Started Button */}
        <button
          onClick={onGetStarted}
          className="w-full py-4 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-2xl shadow-lg hover:shadow-xl transition-all hover:scale-[1.02] active:scale-[0.98]"
        >
          Get Started
        </button>

        {/* Footer */}
        <p className="text-xs text-gray-500 mt-8">
          Powered by AI • Made for Indian Smart Cities
        </p>
      </div>
    </div>
  );
}
