import { ArrowLeft, Table, BarChart3, Camera, TrendingUp, Brain } from 'lucide-react';
import { citizenData, accidentImages, getRiskStats, getAccidentStats } from './mockData';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell } from 'recharts';

interface DashboardScreenProps {
  city: string;
  onNavigate: (screen: 'citizen-risk' | 'accident-detection' | 'ai-workflow') => void;
  onBack: () => void;
}

export function DashboardScreen({ city, onNavigate, onBack }: DashboardScreenProps) {
  const riskStats = getRiskStats(citizenData);
  const accidentStats = getAccidentStats(accidentImages);

  const chartData = [
    { name: 'Low', value: riskStats.low, color: '#10b981' },
    { name: 'Medium', value: riskStats.medium, color: '#f59e0b' },
    { name: 'High', value: riskStats.high, color: '#ef4444' },
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-green-500 rounded-2xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-green-600">
                {city} Dashboard
              </h1>
              <p className="text-gray-600">AI-Powered City Insights</p>
            </div>
          </div>
        </div>

        {/* AI Workflow Button */}
        <button
          onClick={() => onNavigate('ai-workflow')}
          className="w-full mb-6 p-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl flex items-center justify-center gap-2 hover:shadow-lg transition-all hover:scale-[1.01]"
        >
          <Brain className="w-5 h-5" />
          View AI Workflow
        </button>

        {/* Main AI Modules */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Citizen Risk Analysis Card */}
          <button
            onClick={() => onNavigate('citizen-risk')}
            className="bg-white rounded-3xl shadow-lg p-6 md:p-8 hover:shadow-xl transition-all hover:scale-[1.02] text-left"
          >
            <div className="flex items-start gap-4 mb-6">
              <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center flex-shrink-0">
                <span className="text-2xl">🧑‍🤝‍🧑</span>
              </div>
              <div className="flex-1">
                <h2 className="mb-2">Citizen Risk Analysis</h2>
                <div className="flex gap-2 mb-2">
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm">
                    <Table className="w-3 h-3" />
                    CSV-based
                  </span>
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-green-50 text-green-700 rounded-full text-sm">
                    <BarChart3 className="w-3 h-3" />
                    AI Analysis
                  </span>
                </div>
              </div>
            </div>

            <p className="text-gray-600 mb-4">
              AI analyzes sleep, transport, work hours, and carbon footprint
            </p>

            {/* Mini Bar Chart */}
            <div className="bg-gray-50 rounded-2xl p-4 mb-4">
              <p className="text-sm text-gray-600 mb-3">Risk Distribution</p>
              <ResponsiveContainer width="100%" height={120}>
                <BarChart data={chartData}>
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">Total Citizens</span>
              <span className="text-blue-600">{citizenData.length} analyzed</span>
            </div>
          </button>

          {/* Road Accident Detection Card */}
          <button
            onClick={() => onNavigate('accident-detection')}
            className="bg-white rounded-3xl shadow-lg p-6 md:p-8 hover:shadow-xl transition-all hover:scale-[1.02] text-left"
          >
            <div className="flex items-start gap-4 mb-6">
              <div className="w-14 h-14 bg-green-100 rounded-2xl flex items-center justify-center flex-shrink-0">
                <span className="text-2xl">🚦</span>
              </div>
              <div className="flex-1">
                <h2 className="mb-2">Road Accident Detection</h2>
                <div className="flex gap-2 mb-2">
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-green-50 text-green-700 rounded-full text-sm">
                    <Camera className="w-3 h-3" />
                    CCTV Images
                  </span>
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm">
                    <Brain className="w-3 h-3" />
                    AI Vision
                  </span>
                </div>
              </div>
            </div>

            <p className="text-gray-600 mb-4">
              AI detects accidents from CCTV frames in real-time
            </p>

            {/* Image Thumbnails */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="relative rounded-xl overflow-hidden border-2 border-red-200">
                <img 
                  src={accidentImages.find(img => img.hasAccident)?.imageUrl}
                  alt="Accident detected"
                  className="w-full h-24 object-cover"
                />
                <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-lg text-xs">
                  🚨 Accident
                </div>
              </div>
              <div className="relative rounded-xl overflow-hidden border-2 border-green-200">
                <img 
                  src={accidentImages.find(img => !img.hasAccident)?.imageUrl}
                  alt="Normal road"
                  className="w-full h-24 object-cover"
                />
                <div className="absolute top-2 right-2 bg-green-500 text-white px-2 py-1 rounded-lg text-xs">
                  ✅ Normal
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">Detected Incidents</span>
              <span className="text-red-600">{accidentStats.accidents} accidents</span>
            </div>
          </button>
        </div>

        {/* Stats Summary */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          <div className="bg-white rounded-2xl p-4 shadow">
            <div className="text-2xl text-green-600 mb-1">{riskStats.low}</div>
            <div className="text-sm text-gray-600">Low Risk</div>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow">
            <div className="text-2xl text-amber-600 mb-1">{riskStats.medium}</div>
            <div className="text-sm text-gray-600">Medium Risk</div>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow">
            <div className="text-2xl text-red-600 mb-1">{riskStats.high}</div>
            <div className="text-sm text-gray-600">High Risk</div>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow">
            <div className="text-2xl text-blue-600 mb-1">{accidentImages.length}</div>
            <div className="text-sm text-gray-600">CCTV Analyzed</div>
          </div>
        </div>
      </div>
    </div>
  );
}
