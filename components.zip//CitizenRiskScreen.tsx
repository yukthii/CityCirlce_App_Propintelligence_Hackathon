import { useState } from 'react';
import { ArrowLeft, User, Bus, Clock, Briefcase, Leaf } from 'lucide-react';
import { ResultType } from '../App';

interface CitizenRiskScreenProps {
  onBack: () => void;
  onResult: (result: ResultType) => void;
}

const transportModes = ['Walking', 'Public Transport', 'Two-Wheeler', 'EV', 'Car'];

export function CitizenRiskScreen({ onBack, onResult }: CitizenRiskScreenProps) {
  const [age, setAge] = useState('');
  const [transport, setTransport] = useState('');
  const [sleepHours, setSleepHours] = useState('');
  const [workHours, setWorkHours] = useState('');
  const [carbonFootprint, setCarbonFootprint] = useState('');

  const calculateRisk = () => {
    const ageNum = parseInt(age);
    const sleepNum = parseFloat(sleepHours);
    const workNum = parseFloat(workHours);
    const carbonNum = parseFloat(carbonFootprint);

    // Simple AI logic
    let riskScore = 0;

    if (sleepNum < 6) riskScore += 2;
    else if (sleepNum < 7) riskScore += 1;

    if (workNum > 10) riskScore += 2;
    else if (workNum > 9) riskScore += 1;

    if (carbonNum > 400) riskScore += 2;
    else if (carbonNum > 250) riskScore += 1;

    if (transport === 'Car') riskScore += 1;
    else if (transport === 'Walking' || transport === 'EV') riskScore -= 1;

    if (ageNum > 50) riskScore += 1;

    let level: 'low' | 'medium' | 'high';
    if (riskScore >= 4) level = 'high';
    else if (riskScore >= 2) level = 'medium';
    else level = 'low';

    onResult({
      type: 'citizen-risk',
      level,
      data: { age, transport, sleepHours, workHours, carbonFootprint }
    });
  };

  const isFormValid = age && transport && sleepHours && workHours && carbonFootprint;

  return (
    <div className="min-h-screen pb-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-green-500 text-white p-6 rounded-b-[2rem] shadow-lg mb-6">
        <button onClick={onBack} className="flex items-center gap-2 text-white mb-4">
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <span className="text-2xl">🧑‍🤝‍🧑</span>
          </div>
          <div>
            <h2 className="text-white">Citizen Risk Analysis</h2>
            <p className="text-blue-50 text-sm">Enter your details below</p>
          </div>
        </div>
      </div>

      {/* Form */}
      <div className="px-6 space-y-4">
        {/* Age Input */}
        <div className="bg-white rounded-2xl p-5 shadow">
          <label className="flex items-center gap-2 text-gray-700 mb-3">
            <User className="w-5 h-5 text-blue-500" />
            <span>Age</span>
          </label>
          <input
            type="number"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            placeholder="Enter your age"
            className="w-full px-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-xl focus:border-blue-400 focus:outline-none transition-colors"
          />
        </div>

        {/* Transport Mode */}
        <div className="bg-white rounded-2xl p-5 shadow">
          <label className="flex items-center gap-2 text-gray-700 mb-3">
            <Bus className="w-5 h-5 text-green-500" />
            <span>Mode of Transport</span>
          </label>
          <div className="grid grid-cols-2 gap-2">
            {transportModes.map((mode) => (
              <button
                key={mode}
                onClick={() => setTransport(mode)}
                className={`py-3 px-4 rounded-xl border-2 transition-all ${
                  transport === mode
                    ? 'bg-blue-500 text-white border-blue-500'
                    : 'bg-gray-50 text-gray-700 border-gray-200 hover:border-blue-300'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>

        {/* Sleep Hours */}
        <div className="bg-white rounded-2xl p-5 shadow">
          <label className="flex items-center gap-2 text-gray-700 mb-3">
            <Clock className="w-5 h-5 text-purple-500" />
            <span>Sleep Hours (per day)</span>
          </label>
          <input
            type="number"
            step="0.5"
            value={sleepHours}
            onChange={(e) => setSleepHours(e.target.value)}
            placeholder="e.g., 7.5"
            className="w-full px-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-xl focus:border-blue-400 focus:outline-none transition-colors"
          />
        </div>

        {/* Work Hours */}
        <div className="bg-white rounded-2xl p-5 shadow">
          <label className="flex items-center gap-2 text-gray-700 mb-3">
            <Briefcase className="w-5 h-5 text-orange-500" />
            <span>Work Hours (per day)</span>
          </label>
          <input
            type="number"
            step="0.5"
            value={workHours}
            onChange={(e) => setWorkHours(e.target.value)}
            placeholder="e.g., 9"
            className="w-full px-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-xl focus:border-blue-400 focus:outline-none transition-colors"
          />
        </div>

        {/* Carbon Footprint */}
        <div className="bg-white rounded-2xl p-5 shadow">
          <label className="flex items-center gap-2 text-gray-700 mb-3">
            <Leaf className="w-5 h-5 text-green-500" />
            <span>Carbon Footprint (kg CO₂/month)</span>
          </label>
          <input
            type="number"
            value={carbonFootprint}
            onChange={(e) => setCarbonFootprint(e.target.value)}
            placeholder="e.g., 250"
            className="w-full px-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-xl focus:border-blue-400 focus:outline-none transition-colors"
          />
        </div>

        {/* Check Risk Button */}
        <button
          onClick={calculateRisk}
          disabled={!isFormValid}
          className={`w-full py-4 rounded-2xl transition-all shadow-lg ${
            isFormValid
              ? 'bg-gradient-to-r from-blue-500 to-green-500 text-white hover:shadow-xl active:scale-[0.98]'
              : 'bg-gray-200 text-gray-400 cursor-not-allowed'
          }`}
        >
          Check Risk
        </button>

        {/* Info */}
        <div className="bg-blue-50 rounded-2xl p-4 border border-blue-100">
          <p className="text-sm text-blue-900">
            <span className="inline-block mr-2">ℹ️</span>
            Your data is analyzed using AI to assess lifestyle health risks based on Indian smart city standards.
          </p>
        </div>
      </div>
    </div>
  );
}
