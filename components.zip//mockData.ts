export interface CitizenData {
  id: number;
  age: number;
  transportMode: string;
  sleepHours: number;
  carbonFootprint: number;
  workHours: number;
  riskLevel: 'Low' | 'Medium' | 'High';
}

export interface AccidentImage {
  id: number;
  imageUrl: string;
  hasAccident: boolean;
  timestamp: string;
  location: string;
}

export const citizenData: CitizenData[] = [
  { id: 1, age: 28, transportMode: 'Bike', sleepHours: 7.5, carbonFootprint: 120, workHours: 8, riskLevel: 'Low' },
  { id: 2, age: 45, transportMode: 'Car', sleepHours: 5.5, carbonFootprint: 450, workHours: 12, riskLevel: 'High' },
  { id: 3, age: 34, transportMode: 'Public Transit', sleepHours: 7, carbonFootprint: 180, workHours: 9, riskLevel: 'Low' },
  { id: 4, age: 52, transportMode: 'Car', sleepHours: 6, carbonFootprint: 420, workHours: 11, riskLevel: 'High' },
  { id: 5, age: 29, transportMode: 'Walk', sleepHours: 8, carbonFootprint: 80, workHours: 7, riskLevel: 'Low' },
  { id: 6, age: 38, transportMode: 'Car', sleepHours: 6.5, carbonFootprint: 380, workHours: 10, riskLevel: 'Medium' },
  { id: 7, age: 42, transportMode: 'Public Transit', sleepHours: 6, carbonFootprint: 200, workHours: 10, riskLevel: 'Medium' },
  { id: 8, age: 31, transportMode: 'Bike', sleepHours: 7.5, carbonFootprint: 110, workHours: 8, riskLevel: 'Low' },
  { id: 9, age: 48, transportMode: 'Car', sleepHours: 5, carbonFootprint: 500, workHours: 13, riskLevel: 'High' },
  { id: 10, age: 26, transportMode: 'Public Transit', sleepHours: 7, carbonFootprint: 160, workHours: 8, riskLevel: 'Low' },
  { id: 11, age: 55, transportMode: 'Car', sleepHours: 5.5, carbonFootprint: 470, workHours: 11, riskLevel: 'High' },
  { id: 12, age: 33, transportMode: 'Bike', sleepHours: 7, carbonFootprint: 130, workHours: 9, riskLevel: 'Low' },
  { id: 13, age: 40, transportMode: 'Car', sleepHours: 6.5, carbonFootprint: 400, workHours: 10, riskLevel: 'Medium' },
  { id: 14, age: 27, transportMode: 'Walk', sleepHours: 8, carbonFootprint: 90, workHours: 7, riskLevel: 'Low' },
  { id: 15, age: 50, transportMode: 'Car', sleepHours: 5.5, carbonFootprint: 460, workHours: 12, riskLevel: 'High' },
];

export const accidentImages: AccidentImage[] = [
  {
    id: 1,
    imageUrl: 'https://images.unsplash.com/photo-1673187139612-6bf684a74815?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBhY2NpZGVudCUyMHJvYWR8ZW58MXx8fHwxNzY1Nzg1Mzk4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    hasAccident: true,
    timestamp: '2024-12-15 14:23',
    location: 'Main St & 5th Ave'
  },
  {
    id: 2,
    imageUrl: 'https://images.unsplash.com/photo-1722975777516-d68cba23dc41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFmZmljJTIwc3RyZWV0JTIwbm9ybWFsfGVufDF8fHx8MTc2NTc4NTQwMHww&ixlib=rb-4.1.0&q=80&w=1080',
    hasAccident: false,
    timestamp: '2024-12-15 14:25',
    location: 'Park Blvd'
  },
  {
    id: 3,
    imageUrl: 'https://images.unsplash.com/photo-1747639515430-6287d0b102c9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWdod2F5JTIwdHJhZmZpYyUyMGNjdHZ8ZW58MXx8fHwxNzY1Nzg1NDAwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    hasAccident: false,
    timestamp: '2024-12-15 14:28',
    location: 'Highway 101'
  },
  {
    id: 4,
    imageUrl: 'https://images.unsplash.com/photo-1673187139612-6bf684a74815?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBhY2NpZGVudCUyMHJvYWR8ZW58MXx8fHwxNzY1Nzg1Mzk4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    hasAccident: true,
    timestamp: '2024-12-15 15:10',
    location: 'Downtown Center'
  },
  {
    id: 5,
    imageUrl: 'https://images.unsplash.com/photo-1722975777516-d68cba23dc41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFmZmljJTIwc3RyZWV0JTIwbm9ybWFsfGVufDF8fHx8MTc2NTc4NTQwMHww&ixlib=rb-4.1.0&q=80&w=1080',
    hasAccident: false,
    timestamp: '2024-12-15 15:15',
    location: 'Oak Street'
  },
  {
    id: 6,
    imageUrl: 'https://images.unsplash.com/photo-1747639515430-6287d0b102c9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWdod2F5JTIwdHJhZmZpYyUyMGNjdHZ8ZW58MXx8fHwxNzY1Nzg1NDAwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    hasAccident: false,
    timestamp: '2024-12-15 15:20',
    location: 'River Road'
  },
];

export const cities = [
  'San Francisco',
  'New York',
  'Los Angeles',
  'Chicago',
  'Seattle',
  'Boston',
  'Austin',
  'Denver'
];

export const getRiskStats = (data: CitizenData[]) => {
  const low = data.filter(c => c.riskLevel === 'Low').length;
  const medium = data.filter(c => c.riskLevel === 'Medium').length;
  const high = data.filter(c => c.riskLevel === 'High').length;
  
  return { low, medium, high };
};

export const getAccidentStats = (data: AccidentImage[]) => {
  const accidents = data.filter(img => img.hasAccident).length;
  const normal = data.filter(img => !img.hasAccident).length;
  
  return { accidents, normal };
};
