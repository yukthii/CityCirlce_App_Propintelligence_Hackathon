import { CheckCircle, AlertTriangle, AlertCircle, Home, Share2 } from 'lucide-react';
import { ResultType } from '../App';

interface ResultScreenProps {
  result: ResultType;
  onBack: () => void;
}

export function ResultScreen({ result, onBack }: ResultScreenProps) {
  const isCitizenRisk = result.type === 'citizen-risk';

  const getRiskColor = (level?: string) => {
    switch (level) {
      case 'low': return 'from-green-400 to-green-500';
      case 'medium': return 'from-orange-400 to-orange-500';
      case 'high': return 'from-red-400 to-red-500';
      default: return 'from-blue-400 to-blue-500';
    }
  };

  const getRiskIcon = (level?: string) => {
    switch (level) {
      case 'low': return '🟢';
      case 'medium': return '🟠';
      case 'high': return '🔴';
      default: return '✅';
    }
  };

  const getRiskMessage = (level?: string) => {
    switch (level) {
      case 'low':
        return {
          title: 'Low Risk',
          message: 'Great! Your lifestyle shows healthy patterns. Keep maintaining good sleep, work-life balance, and sustainable transport choices.',
          tips: [
            'Continue your current routine',
            'Stay active and healthy',
            'Maintain eco-friendly habits'
          ]
        };
      case 'medium':
        return {
          title: 'Medium Risk',
          message: 'Your lifestyle has moderate health risks. Consider improving sleep hours, reducing work stress, or choosing greener transport options.',
          tips: [
            'Try to get 7-8 hours of sleep',
            'Balance work and personal time',
            'Consider public transport or EV'
          ]
        };
      case 'high':
        return {
          title: 'High Risk',
          message: 'Warning: Your lifestyle shows significant health risks. We recommend immediate changes to improve sleep, reduce work hours, and lower your carbon footprint.',
          tips: [
            'Prioritize rest and sleep quality',
            'Reduce overtime work hours',
            'Switch to sustainable transport',
            'Consult a wellness advisor'
          ]
        };
      default:
        return {
          title: 'Analysis Complete',
          message: 'Result processed successfully',
          tips: []
        };
    }
  };

  const getAccidentMessage = (hasAccident?: boolean) => {
    if (hasAccident) {
      return {
        title: 'Accident Detected',
        icon: '🚨',
        message: 'Our AI has detected signs of an accident in the uploaded image. Emergency services have been notified.',
        color: 'from-red-400 to-red-500',
        actions: [
          'Emergency services alerted',
          'Location marked for response',
          'Traffic authorities notified'
        ]
      };
    } else {
      return {
        title: 'No Accident Detected',
        icon: '✅',
        message: 'The road appears clear with normal traffic flow. No immediate action required.',
        color: 'from-green-400 to-green-500',
        actions: [
          'Traffic flowing normally',
          'No hazards detected',
          'Continued monitoring active'
        ]
      };
    }
  };

  const citizenInfo = isCitizenRisk ? getRiskMessage(result.level) : null;
  const accidentInfo = !isCitizenRisk ? getAccidentMessage(result.hasAccident) : null;

  return (
    <div className="min-h-screen pb-8">
      {/* Header with Result Icon */}
      <div className={`bg-gradient-to-r ${
        isCitizenRisk ? getRiskColor(result.level) : accidentInfo?.color
      } text-white p-6 pb-20 rounded-b-[3rem] shadow-lg mb-[-3rem] relative`}>
        <div className="text-center">
          <div className="text-6xl mb-4">
            {isCitizenRisk ? getRiskIcon(result.level) : accidentInfo?.icon}
          </div>
          <h2 className="text-white mb-2">
            {isCitizenRisk ? citizenInfo?.title : accidentInfo?.title}
          </h2>
          <p className="text-white/90 text-sm">
            AI Analysis Complete
          </p>
        </div>
      </div>

      {/* Result Card */}
      <div className="px-6 space-y-4">
        <div className="bg-white rounded-3xl p-6 shadow-xl">
          <div className="mb-6">
            <h3 className="text-gray-900 mb-3">Analysis Result</h3>
            <p className="text-gray-700">
              {isCitizenRisk ? citizenInfo?.message : accidentInfo?.message}
            </p>
          </div>

          {/* Tips or Actions */}
          {isCitizenRisk && citizenInfo && citizenInfo.tips.length > 0 && (
            <div className="bg-blue-50 rounded-2xl p-4 mb-4">
              <h4 className="text-blue-900 mb-2">Recommendations</h4>
              <ul className="space-y-2">
                {citizenInfo.tips.map((tip, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm text-blue-800">
                    <span className="text-blue-500 mt-0.5">•</span>
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {!isCitizenRisk && accidentInfo && accidentInfo.actions.length > 0 && (
            <div className={`${result.hasAccident ? 'bg-red-50' : 'bg-green-50'} rounded-2xl p-4 mb-4`}>
              <h4 className={`${result.hasAccident ? 'text-red-900' : 'text-green-900'} mb-2`}>
                Actions Taken
              </h4>
              <ul className="space-y-2">
                {accidentInfo.actions.map((action, index) => (
                  <li key={index} className={`flex items-start gap-2 text-sm ${result.hasAccident ? 'text-red-800' : 'text-green-800'}`}>
                    <CheckCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span>{action}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Data Summary for Citizen Risk */}
          {isCitizenRisk && result.data && (
            <div className="border-t border-gray-200 pt-4">
              <h4 className="text-gray-900 mb-3">Your Input Data</h4>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="bg-gray-50 rounded-xl p-3">
                  <div className="text-gray-500 mb-1">Age</div>
                  <div className="text-gray-900">{result.data.age} years</div>
                </div>
                <div className="bg-gray-50 rounded-xl p-3">
                  <div className="text-gray-500 mb-1">Transport</div>
                  <div className="text-gray-900">{result.data.transport}</div>
                </div>
                <div className="bg-gray-50 rounded-xl p-3">
                  <div className="text-gray-500 mb-1">Sleep</div>
                  <div className="text-gray-900">{result.data.sleepHours}h</div>
                </div>
                <div className="bg-gray-50 rounded-xl p-3">
                  <div className="text-gray-500 mb-1">Work</div>
                  <div className="text-gray-900">{result.data.workHours}h</div>
                </div>
                <div className="bg-gray-50 rounded-xl p-3 col-span-2">
                  <div className="text-gray-500 mb-1">Carbon Footprint</div>
                  <div className="text-gray-900">{result.data.carbonFootprint} kg CO₂/month</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* AI Note */}
        <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-4 border border-purple-100">
          <p className="text-sm text-gray-700">
            <span className="inline-block mr-2">🤖</span>
            <strong>AI insights based on Indian smart city data</strong>
          </p>
          <p className="text-xs text-gray-600 mt-2">
            Our AI models are trained on comprehensive datasets from Indian urban environments to provide accurate, context-aware analysis.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <button
            onClick={onBack}
            className="flex-1 py-4 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-2xl flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all active:scale-[0.98]"
          >
            <Home className="w-5 h-5" />
            Back to Home
          </button>
          <button className="px-6 py-4 bg-white text-gray-700 rounded-2xl shadow-lg hover:shadow-xl transition-all active:scale-[0.98] border border-gray-200">
            <Share2 className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
