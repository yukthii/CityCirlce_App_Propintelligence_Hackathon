import { useState } from 'react';
import { ArrowLeft, Camera, Upload, Image as ImageIcon } from 'lucide-react';
import { ResultType } from '../App';

interface AccidentDetectionScreenProps {
  onBack: () => void;
  onResult: (result: ResultType) => void;
}

export function AccidentDetectionScreen({ onBack, onResult }: AccidentDetectionScreenProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imageUploaded, setImageUploaded] = useState(false);

  // Sample images for demo
  const sampleImages = [
    {
      url: 'https://images.unsplash.com/photo-1673187139612-6bf684a74815?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBhY2NpZGVudCUyMHJvYWR8ZW58MXx8fHwxNzY1Nzg1Mzk4fDA&ixlib=rb-4.1.0&q=80&w=1080',
      hasAccident: true,
      label: 'Accident Scene'
    },
    {
      url: 'https://images.unsplash.com/photo-1722975777516-d68cba23dc41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFmZmljJTIwc3RyZWV0JTIwbm9ybWFsfGVufDF8fHx8MTc2NTc4NTQwMHww&ixlib=rb-4.1.0&q=80&w=1080',
      hasAccident: false,
      label: 'Normal Traffic'
    },
    {
      url: 'https://images.unsplash.com/photo-1747639515430-6287d0b102c9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWdod2F5JTIwdHJhZmZpYyUyMGNjdHZ8ZW58MXx8fHwxNzY1Nzg1NDAwfDA&ixlib=rb-4.1.0&q=80&w=1080',
      hasAccident: false,
      label: 'Highway Traffic'
    }
  ];

  const handleImageSelect = (imageUrl: string, hasAccident: boolean) => {
    setSelectedImage(imageUrl);
    setImageUploaded(true);
    // Store accident info for later analysis
    (window as any).__selectedImageHasAccident = hasAccident;
  };

  const handleAnalyze = () => {
    const hasAccident = (window as any).__selectedImageHasAccident || false;
    onResult({
      type: 'accident-detection',
      hasAccident
    });
  };

  return (
    <div className="min-h-screen pb-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-green-500 text-white p-6 rounded-b-[2rem] shadow-lg mb-6">
        <button onClick={onBack} className="flex items-center gap-2 text-white mb-4">
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <span className="text-2xl">🚦</span>
          </div>
          <div>
            <h2 className="text-white">Accident Detection</h2>
            <p className="text-blue-50 text-sm">Upload a road image</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 space-y-6">
        {/* Upload Section */}
        {!imageUploaded && (
          <div className="bg-white rounded-3xl p-8 shadow-lg">
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Camera className="w-10 h-10 text-blue-500" />
              </div>
              <h3 className="text-gray-900 mb-2">Upload Road Image</h3>
              <p className="text-sm text-gray-600">
                Choose from sample images below or upload your own
              </p>
            </div>

            <div className="flex gap-3 mb-4">
              <button className="flex-1 py-4 bg-blue-500 text-white rounded-2xl flex items-center justify-center gap-2 shadow hover:shadow-lg transition-all active:scale-[0.98]">
                <Camera className="w-5 h-5" />
                Camera
              </button>
              <button className="flex-1 py-4 bg-green-500 text-white rounded-2xl flex items-center justify-center gap-2 shadow hover:shadow-lg transition-all active:scale-[0.98]">
                <Upload className="w-5 h-5" />
                Gallery
              </button>
            </div>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">or try sample images</span>
              </div>
            </div>
          </div>
        )}

        {/* Sample Images */}
        {!imageUploaded && (
          <div>
            <p className="text-gray-700 mb-3">Select a sample image:</p>
            <div className="grid grid-cols-1 gap-3">
              {sampleImages.map((image, index) => (
                <button
                  key={index}
                  onClick={() => handleImageSelect(image.url, image.hasAccident)}
                  className="relative rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all active:scale-[0.98]"
                >
                  <img
                    src={image.url}
                    alt={image.label}
                    className="w-full h-40 object-cover"
                  />
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-3">
                    <p className="text-white text-sm">{image.label}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Image Preview */}
        {imageUploaded && selectedImage && (
          <div className="space-y-4">
            <div className="bg-white rounded-3xl p-4 shadow-lg">
              <div className="flex items-center gap-2 mb-3">
                <ImageIcon className="w-5 h-5 text-blue-500" />
                <span className="text-gray-700">Preview</span>
              </div>
              <div className="relative rounded-2xl overflow-hidden">
                <img
                  src={selectedImage}
                  alt="Selected road"
                  className="w-full h-64 object-cover"
                />
              </div>
            </div>

            {/* Analyze Button */}
            <button
              onClick={handleAnalyze}
              className="w-full py-4 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-2xl shadow-lg hover:shadow-xl transition-all active:scale-[0.98]"
            >
              Analyze Image
            </button>

            {/* Change Image */}
            <button
              onClick={() => {
                setImageUploaded(false);
                setSelectedImage(null);
              }}
              className="w-full py-4 bg-gray-100 text-gray-700 rounded-2xl hover:bg-gray-200 transition-all"
            >
              Change Image
            </button>
          </div>
        )}

        {/* Info */}
        <div className="bg-green-50 rounded-2xl p-4 border border-green-100">
          <p className="text-sm text-green-900">
            <span className="inline-block mr-2">ℹ️</span>
            Our AI uses computer vision trained on Indian road conditions to detect accidents in real-time.
          </p>
        </div>
      </div>
    </div>
  );
}
