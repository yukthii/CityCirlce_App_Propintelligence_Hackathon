import { ArrowLeft, ArrowRight, FileSpreadsheet, Camera, Brain, TrendingUp, AlertCircle, Database } from 'lucide-react';

interface AIWorkflowScreenProps {
  onBack: () => void;
}

export function AIWorkflowScreen({ onBack }: AIWorkflowScreenProps) {
  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Dashboard
          </button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
                AI Workflow
              </h1>
              <p className="text-gray-600">How CityCircle Processes Data</p>
            </div>
          </div>
        </div>

        {/* Workflow 1: CSV-based Analysis */}
        <div className="bg-white rounded-3xl shadow-lg p-6 md:p-8 mb-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
              <span className="text-xl">🧑‍🤝‍🧑</span>
            </div>
            <h2 className="text-blue-900">Citizen Risk Analysis Workflow</h2>
          </div>

          {/* Flow Diagram */}
          <div className="space-y-4">
            {/* Step 1 */}
            <div className="flex items-center gap-4">
              <div className="flex-shrink-0 w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center">
                <FileSpreadsheet className="w-8 h-8 text-blue-600" />
              </div>
              <div className="flex-1">
                <div className="bg-blue-50 rounded-2xl p-4">
                  <h3 className="text-blue-900 mb-1">Step 1: CSV Dataset</h3>
                  <p className="text-blue-700 text-sm">
                    Collect citizen activity data: age, transport mode, sleep hours, work hours, carbon footprint
                  </p>
                </div>
              </div>
            </div>

            {/* Arrow */}
            <div className="flex justify-center">
              <ArrowRight className="w-6 h-6 text-gray-400 rotate-90" />
            </div>

            {/* Step 2 */}
            <div className="flex items-center gap-4">
              <div className="flex-shrink-0 w-16 h-16 bg-purple-50 rounded-2xl flex items-center justify-center">
                <Brain className="w-8 h-8 text-purple-600" />
              </div>
              <div className="flex-1">
                <div className="bg-purple-50 rounded-2xl p-4">
                  <h3 className="text-purple-900 mb-1">Step 2: AI Risk Logic</h3>
                  <p className="text-purple-700 text-sm">
                    Machine learning model analyzes patterns and assigns risk levels (Low/Medium/High)
                  </p>
                  <div className="mt-2 text-xs text-purple-600 font-mono bg-white rounded-lg p-2">
                    if (sleep &lt; 6 && workHours &gt; 10 && carbonFootprint &gt; 400) → High Risk
                  </div>
                </div>
              </div>
            </div>

            {/* Arrow */}
            <div className="flex justify-center">
              <ArrowRight className="w-6 h-6 text-gray-400 rotate-90" />
            </div>

            {/* Step 3 */}
            <div className="flex items-center gap-4">
              <div className="flex-shrink-0 w-16 h-16 bg-green-50 rounded-2xl flex items-center justify-center">
                <TrendingUp className="w-8 h-8 text-green-600" />
              </div>
              <div className="flex-1">
                <div className="bg-green-50 rounded-2xl p-4">
                  <h3 className="text-green-900 mb-1">Step 3: City Insights</h3>
                  <p className="text-green-700 text-sm">
                    Generate actionable insights for city planners to improve citizen well-being
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Workflow 2: Image-based Detection */}
        <div className="bg-white rounded-3xl shadow-lg p-6 md:p-8 mb-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
              <span className="text-xl">🚦</span>
            </div>
            <h2 className="text-green-900">Accident Detection Workflow</h2>
          </div>

          {/* Flow Diagram */}
          <div className="space-y-4">
            {/* Step 1 */}
            <div className="flex items-center gap-4">
              <div className="flex-shrink-0 w-16 h-16 bg-green-50 rounded-2xl flex items-center justify-center">
                <Camera className="w-8 h-8 text-green-600" />
              </div>
              <div className="flex-1">
                <div className="bg-green-50 rounded-2xl p-4">
                  <h3 className="text-green-900 mb-1">Step 1: CCTV Images</h3>
                  <p className="text-green-700 text-sm">
                    Real-time capture of road footage from city CCTV cameras
                  </p>
                </div>
              </div>
            </div>

            {/* Arrow */}
            <div className="flex justify-center">
              <ArrowRight className="w-6 h-6 text-gray-400 rotate-90" />
            </div>

            {/* Step 2 */}
            <div className="flex items-center gap-4">
              <div className="flex-shrink-0 w-16 h-16 bg-purple-50 rounded-2xl flex items-center justify-center">
                <Brain className="w-8 h-8 text-purple-600" />
              </div>
              <div className="flex-1">
                <div className="bg-purple-50 rounded-2xl p-4">
                  <h3 className="text-purple-900 mb-1">Step 2: AI Vision Logic</h3>
                  <p className="text-purple-700 text-sm">
                    Computer vision model detects accidents, collisions, and anomalies in real-time
                  </p>
                  <div className="mt-2 text-xs text-purple-600 font-mono bg-white rounded-lg p-2">
                    CNN Model → Object Detection → Accident Classification
                  </div>
                </div>
              </div>
            </div>

            {/* Arrow */}
            <div className="flex justify-center">
              <ArrowRight className="w-6 h-6 text-gray-400 rotate-90" />
            </div>

            {/* Step 3 */}
            <div className="flex items-center gap-4">
              <div className="flex-shrink-0 w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center">
                <AlertCircle className="w-8 h-8 text-red-600" />
              </div>
              <div className="flex-1">
                <div className="bg-red-50 rounded-2xl p-4">
                  <h3 className="text-red-900 mb-1">Step 3: Accident Alerts</h3>
                  <p className="text-red-700 text-sm">
                    Automatic notification to emergency services with location and severity data
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Data Integration */}
        <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-3xl shadow-lg p-6 md:p-8">
          <div className="flex items-center gap-3 mb-4">
            <Database className="w-8 h-8 text-blue-600" />
            <h2 className="text-gray-900">Dual Dataset Integration</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-white rounded-2xl p-4">
              <h3 className="text-blue-900 mb-2">📊 Structured Data (CSV)</h3>
              <ul className="text-sm text-gray-700 space-y-1">
                <li>• Citizen demographics</li>
                <li>• Lifestyle metrics</li>
                <li>• Transport patterns</li>
                <li>• Environmental impact</li>
              </ul>
            </div>
            <div className="bg-white rounded-2xl p-4">
              <h3 className="text-green-900 mb-2">🖼️ Unstructured Data (Images)</h3>
              <ul className="text-sm text-gray-700 space-y-1">
                <li>• CCTV footage</li>
                <li>• Road conditions</li>
                <li>• Accident scenes</li>
                <li>• Traffic patterns</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Tech Stack */}
        <div className="mt-6 bg-white rounded-2xl shadow p-6">
          <h3 className="text-gray-900 mb-4">AI Technologies Used</h3>
          <div className="flex flex-wrap gap-2">
            <span className="px-4 py-2 bg-blue-50 text-blue-700 rounded-xl text-sm">Machine Learning</span>
            <span className="px-4 py-2 bg-green-50 text-green-700 rounded-xl text-sm">Computer Vision</span>
            <span className="px-4 py-2 bg-purple-50 text-purple-700 rounded-xl text-sm">CNN Models</span>
            <span className="px-4 py-2 bg-pink-50 text-pink-700 rounded-xl text-sm">Real-time Processing</span>
            <span className="px-4 py-2 bg-yellow-50 text-yellow-700 rounded-xl text-sm">Data Analytics</span>
            <span className="px-4 py-2 bg-red-50 text-red-700 rounded-xl text-sm">Alert Systems</span>
          </div>
        </div>
      </div>
    </div>
  );
}
