import { Home, BarChart3, User, ChevronRight } from 'lucide-react';
import { Screen } from '../App';

interface HomeDashboardProps {
  onNavigate: (screen: Screen) => void;
  currentTab: string;
}

export function HomeDashboard({ onNavigate, currentTab }: HomeDashboardProps) {
  return (
    <div className="min-h-screen flex flex-col pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-green-500 text-white p-6 rounded-b-[2rem] shadow-lg">
        <h2 className="text-white mb-1">Welcome to CityCircle</h2>
        <p className="text-blue-50">Choose an AI-powered analysis</p>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-6 space-y-4">
        {/* Citizen Risk Analysis Card */}
        <button
          onClick={() => onNavigate('citizen-risk')}
          className="w-full bg-white rounded-3xl shadow-lg p-6 hover:shadow-xl transition-all active:scale-[0.98] text-left"
        >
          <div className="flex items-start gap-4 mb-4">
            <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center flex-shrink-0">
              <span className="text-3xl">🧑‍🤝‍🧑</span>
            </div>
            <div className="flex-1">
              <h3 className="text-gray-900 mb-2">Citizen Risk Analysis</h3>
              <p className="text-sm text-gray-600">
                Analyze lifestyle patterns and get personalized health insights
              </p>
            </div>
            <ChevronRight className="w-6 h-6 text-gray-400 flex-shrink-0 mt-1" />
          </div>
          <div className="flex gap-2">
            <span className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-xs">
              CSV-based AI
            </span>
            <span className="px-3 py-1 bg-green-50 text-green-700 rounded-full text-xs">
              Instant Results
            </span>
          </div>
        </button>

        {/* Road Accident Detection Card */}
        <button
          onClick={() => onNavigate('accident-detection')}
          className="w-full bg-white rounded-3xl shadow-lg p-6 hover:shadow-xl transition-all active:scale-[0.98] text-left"
        >
          <div className="flex items-start gap-4 mb-4">
            <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center flex-shrink-0">
              <span className="text-3xl">🚦</span>
            </div>
            <div className="flex-1">
              <h3 className="text-gray-900 mb-2">Road Accident Detection</h3>
              <p className="text-sm text-gray-600">
                Upload road images for AI-powered accident detection
              </p>
            </div>
            <ChevronRight className="w-6 h-6 text-gray-400 flex-shrink-0 mt-1" />
          </div>
          <div className="flex gap-2">
            <span className="px-3 py-1 bg-green-50 text-green-700 rounded-full text-xs">
              Image AI
            </span>
            <span className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-xs">
              Real-time
            </span>
          </div>
        </button>

        {/* Info Card */}
        <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-2xl p-5 border border-blue-100">
          <p className="text-sm text-gray-700">
            <span className="inline-block mr-2">💡</span>
            <strong>Dual AI System:</strong> We use CSV data analysis and computer vision to make Indian cities smarter and safer.
          </p>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-3 rounded-t-3xl shadow-lg">
        <div className="max-w-md mx-auto flex items-center justify-around">
          <button className={`flex flex-col items-center gap-1 p-2 ${currentTab === 'home' ? 'text-blue-600' : 'text-gray-400'}`}>
            <Home className="w-6 h-6" />
            <span className="text-xs">Home</span>
          </button>
          <button className={`flex flex-col items-center gap-1 p-2 ${currentTab === 'analyze' ? 'text-blue-600' : 'text-gray-400'}`}>
            <BarChart3 className="w-6 h-6" />
            <span className="text-xs">Analyze</span>
          </button>
          <button className={`flex flex-col items-center gap-1 p-2 ${currentTab === 'profile' ? 'text-blue-600' : 'text-gray-400'}`}>
            <User className="w-6 h-6" />
            <span className="text-xs">Profile</span>
          </button>
        </div>
      </div>
    </div>
  );
}
